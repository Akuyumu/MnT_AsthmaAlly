package com.example.asthmaally; // Keep your original package name

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import androidx.viewpager2.widget.ViewPager2;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TabLayout tabLayout = findViewById(R.id.tabLayout);
        ViewPager2 viewPager = findViewById(R.id.viewPager);
        FragmentAdapter adapter = new FragmentAdapter(this);
        viewPager.setAdapter(adapter);

// Link TabLayout with ViewPager
        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> {
                    switch (position) {
                        case 0:
                            tab.setText("Bluetooth");
                            break;
                        case 1:
                            tab.setText("Questions");
                            break;
                        case 2:
                            tab.setText("Counter");
                            break;
                    }
                }).attach();
        }


}
