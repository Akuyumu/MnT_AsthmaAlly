package com.example.asthmaally;


import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import java.util.ArrayList;
import android.content.pm.PackageManager;
import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import java.util.List;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import android.os.Handler;
import android.os.Looper;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothGattDescriptor;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.util.Log;


public class BluetoothFragment extends Fragment {
    // Nordic UART Service UUIDs
    private static final UUID UART_SERVICE_UUID = UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID TX_CHARACTERISTIC_UUID = UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e");
    private static final UUID RX_CHARACTERISTIC_UUID = UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e");

    private BluetoothGatt bluetoothGatt;
    private TextView txtSpO2;
    private TextView txtRespiration;

    private LineChart chartBreathe;
    private LineDataSet dataSet;
    private LineData lineData;
    private int breatheIndex = 0;




    TextView txtData;
    LineChart chart;

    Button btnConnect;

    private final List<BluetoothDevice> bleDevices = new ArrayList<>();
    private final List<String> bleDeviceNames = new ArrayList<>();
    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if (ContextCompat.checkSelfPermission(requireContext(),Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                    String deviceName = device.getName();
                    if (deviceName == null) {
                        deviceName = "Unknown Device";
                    }
                    if (!bleDevices.contains(device)) {
                        bleDevices.add(device);
                        bleDeviceNames.add(deviceName); // make sure deviceName is already set
                    }

                }
            }
        }
    };
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                requireActivity().runOnUiThread(() -> txtData.append("\nConnected! Discovering services..."));
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                    gatt.discoverServices();
                } else {
                    requireActivity().runOnUiThread(() -> txtData.append("\nPermission denied to discover services."));
                }


            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                requireActivity().runOnUiThread(() -> txtData.append("\nDisconnected from device."));
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            BluetoothGattService uartService = gatt.getService(UART_SERVICE_UUID);
            if (uartService != null) {
                BluetoothGattCharacteristic txChar = uartService.getCharacteristic(TX_CHARACTERISTIC_UUID);
                if (txChar != null) {
                    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED) {
                        gatt.setCharacteristicNotification(txChar, true);
                    }
                    // Set up descriptor for notifications
                    BluetoothGattDescriptor descriptor = txChar.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb"));
                    if (descriptor != null) {
                        descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                        gatt.writeDescriptor(descriptor);
                    }

                    requireActivity().runOnUiThread(() -> txtData.append("\nUART TX characteristic found and notifications enabled."));
                } else {
                    requireActivity().runOnUiThread(() -> txtData.append("\nTX characteristic not found."));
                }
            } else {
                requireActivity().runOnUiThread(() -> txtData.append("\nUART Service not found."));
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            if (TX_CHARACTERISTIC_UUID.equals(characteristic.getUuid())) {
                byte[] data = characteristic.getValue();
                String received = new String(data, StandardCharsets.UTF_8);
                String[] parts = received.split(",");
                for (String part : parts) {
                    if (part.startsWith("SPO2:")) {
                        String sp = part.substring(5);
                        requireActivity().runOnUiThread(() -> txtSpO2.setText("SpO2: " + sp));
                    } else if (part.startsWith("RESP:")) {
                        String resp = part.substring(5);
                        requireActivity().runOnUiThread(() -> txtRespiration.setText("Respiration: " + resp));
                    }else if (part.startsWith("Breathe:")) {
                        try {
                            float value = Float.parseFloat(part.substring(8)); // Extract value after "Breathe:"
                            requireActivity().runOnUiThread(() -> addBreatheEntry(value)); // Add to graph
                        } catch (Exception e) {
                            Log.e("BluetoothFragment", "Invalid breathe data: " + part);
                        }
                    }
                }

            }
        }

    };
    private void addBreatheEntry(float value) {
        if (dataSet.getEntryCount() >= 20) {
            dataSet.removeFirst(); // drop oldest entry
            for (Entry e : dataSet.getValues()) {
                e.setX(e.getX() - 1); // shift x-axis
            }
            breatheIndex = 19;
        }

        dataSet.addEntry(new Entry(breatheIndex++, value));
        dataSet.notifyDataSetChanged();
        lineData.notifyDataChanged();
        chartBreathe.notifyDataSetChanged();
        chartBreathe.invalidate(); // refresh
    }

    public BluetoothFragment() {
        // Required empty public constructor
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_bluetooth, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        txtSpO2 = view.findViewById(R.id.txtSpO2);
        txtRespiration = view.findViewById(R.id.txtRespiration);

        // Register BroadcastReceiver
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        requireActivity().registerReceiver(receiver, filter);

        // Request permissions
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.BLUETOOTH_CONNECT)
                != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.BLUETOOTH_SCAN)
                        != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                        != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.ACCESS_FINE_LOCATION
            }, 1);
        }
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        if (bluetoothAdapter == null) {
            txtData.setText("Bluetooth not supported on this device.");
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, 1);
        }

        txtData = view.findViewById(R.id.txtData);
        btnConnect = view.findViewById(R.id.btnConnect);
        chartBreathe = view.findViewById(R.id.chartBreathe);
        dataSet = new LineDataSet(new ArrayList<>(), "Breathing");
        dataSet.setColor(Color.BLUE);
        dataSet.setLineWidth(2f);
        dataSet.setDrawCircles(false);
        dataSet.setMode(LineDataSet.Mode.LINEAR);

        lineData = new LineData(dataSet);
        chartBreathe.setData(lineData);

        chartBreathe.getDescription().setEnabled(false);
        chartBreathe.getLegend().setEnabled(false);


        btnConnect.setOnClickListener(v -> {
            txtData.setText("Scanning for Bluetooth devices...");

            // Start discovery
            if (bluetoothAdapter.isDiscovering()) {
                bluetoothAdapter.cancelDiscovery();
            }
            bleDevices.clear();
            bleDeviceNames.clear();
            bluetoothAdapter.startDiscovery();

            // 🔽 ADD THIS TO AUTO SHOW DEVICE PICKER AFTER 5 SECONDS
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                bluetoothAdapter.cancelDiscovery();  // stop scanning
                showDevicePicker();                 // show picker dialog
            }, 5000); // 5-second delay
            bluetoothAdapter.startDiscovery();
        });
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        requireActivity().unregisterReceiver(receiver);
    }

    private void showDevicePicker() {
        String[] devicesArray = bleDeviceNames.toArray(new String[0]);

        new AlertDialog.Builder(requireContext())
                .setTitle("Select a Bluetooth Device")
                .setItems(devicesArray, (dialog, which) -> {
                    BluetoothDevice selectedDevice = bleDevices.get(which);
                    if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.BLUETOOTH_CONNECT)
                            == PackageManager.PERMISSION_GRANTED) {
                        String deviceName = selectedDevice.getName();
                        String deviceAddress = selectedDevice.getAddress();
                        txtData.append("\nConnecting to: " + deviceName + " [" + deviceAddress + "]");

                        bluetoothGatt = selectedDevice.connectGatt(requireContext(), false, gattCallback);

                    } else {
                        txtData.append("\nPermission denied to get device name/address.");
                    }

                })
                .setNegativeButton("Cancel", null)
                .show();
    }
}

