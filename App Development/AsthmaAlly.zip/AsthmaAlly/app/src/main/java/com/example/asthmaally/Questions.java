package com.example.asthmaally;

public class Questions {
    public String text;
    public String[] options;

    public Questions(String text, String[] options) {
        this.text = text;
        this.options = options;
    }
}
