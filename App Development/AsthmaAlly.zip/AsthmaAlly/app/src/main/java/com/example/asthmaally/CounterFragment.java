package com.example.asthmaally;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class CounterFragment extends Fragment {

    private static final String PREFS_NAME = "AttackPrefs";
    private static final String KEY_COUNT = "attack_count";
    private static final String KEY_TIMESTAMP = "week_start_time";

    private TextView txtAttackCount;
    private SharedPreferences prefs;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_counter, container, false);

        Button btnAttack = view.findViewById(R.id.btnAttack);
        txtAttackCount = view.findViewById(R.id.txtAttackCount);

        prefs = requireContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        resetIfNewWeek();
        updateDisplay();

        btnAttack.setOnClickListener(v -> {
            int count = prefs.getInt(KEY_COUNT, 0);
            prefs.edit().putInt(KEY_COUNT, count + 1).apply();
            updateDisplay();
        });

        return view;
    }

    private void updateDisplay() {
        int count = prefs.getInt(KEY_COUNT, 0);
        txtAttackCount.setText("Number of asthma attacks this week: " + count);
    }

    private void resetIfNewWeek() {
        long savedTime = prefs.getLong(KEY_TIMESTAMP, 0);
        long now = System.currentTimeMillis();
        long sevenDaysMillis = 7L * 24 * 60 * 60 * 1000;

        if (now - savedTime > sevenDaysMillis) {
            prefs.edit()
                    .putInt(KEY_COUNT, 0)
                    .putLong(KEY_TIMESTAMP, now)
                    .apply();
        }
    }
}
