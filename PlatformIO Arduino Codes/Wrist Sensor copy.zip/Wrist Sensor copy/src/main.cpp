#include <Arduino.h>
#include <Wire.h> // I2C library
#include "Adafruit_TinyUSB.h"
#include "Adafruit_NeoPixel.h" // Neopixel LED library
#include "MAX30105.h" // MAX30105 or MAx30102 library
#include "spo2_algorithm.h" //SpO2 Sensor library

#define VBATPIN A6 // Battery voltage analog pin
#define NEOPIXELPIN 8 // Neopixel control pin
#define NUMPIXELS 1 // Number of neopixels
#define MAX_BRIGHTNESS 255 // for MAX30102

// Put variable declaration here
float VBat;

uint32_t irBuffer[100]; //infrared LED sensor data
uint32_t redBuffer[100];  //red LED sensor data

int32_t bufferLength = 100; //data length
int32_t spo2; //SPO2 value
int8_t validSPO2; //indicator to show if the SPO2 calculation is valid
int32_t heartRate; //heart rate value
int8_t validHeartRate; //indicator to show if the heart rate calculation is valid

// Put function declaration here
float getBattVoltage(int x);
void VBatIndicator();
void FillSensorBuffer();

// Initialize NeoPixel
Adafruit_NeoPixel pixel = Adafruit_NeoPixel(NUMPIXELS, NEOPIXELPIN, NEO_GRB + NEO_KHZ800);

//Initialise MAX30102 SpO2 Sensor
MAX30105 particleSensor;

void setup() {
  // put your setup code here, to run once:

  // Initialize NeoPixel
  pixel.begin();
  pixel.setBrightness(20); // Set brightness (0-255)
  pixel.show(); // Initialize all pixels to 'off'

  Serial.begin(9600);
  delay(2000);
  Serial.println("Hello World");
  Wire.begin(); // Initialize I2C

  // // Initialize MAX30102
  // if (!particleSensor.begin(Wire, I2C_SPEED_FAST)) {
  //   Serial.println("MAX30102 not found! Check wiring.");
  //   while (1); // Halt if sensor not found
  // }

  // Serial.println(F("Attach sensor to finger with rubber band. Press any key to start conversion"));
  // while (Serial.available() == 0) ; //wait until user presses a key
  // Serial.read();

  // Configure sensor for SpO2 monitoring
  particleSensor.setup(60, 4, 2, 100, 411, 4096); 
  /*
  Parameters: 
  LED brightness (0-255)
  Sample averaging (1, 2, 4, 8, 16, 32)
  LED mode (1 = Red, 2 = Red + IR)
  Sample rate (50, 100, 200, 400, 800, 1000, 1600, 3200)
  Pulse width (69, 118, 215, 411)
  ADC range (2048, 4096, 8192, 16384)
  */
}

void loop() {
  // put your main code here, to run repeatedly
  // Sequence to indicate battery status
  VBat =  getBattVoltage(analogRead(VBATPIN)); 
  VBatIndicator();
  Serial.println("hello i'm running");
  
  //read the first 100 samples, and determine the signal range
  static bool bufferfill = false;
  if (!bufferfill) {
      FillSensorBuffer();
      maxim_heart_rate_and_oxygen_saturation(irBuffer, bufferLength, redBuffer, &spo2, &validSPO2, &heartRate, &validHeartRate);
      bufferfill = true;
  }
  //dumping the first 25 sets of samples in the memory and shift the last 75 sets of samples to the top
  for (byte i = 25; i < 100; i++)
    {
      redBuffer[i - 25] = redBuffer[i];
      irBuffer[i - 25] = irBuffer[i];
    }

  //take 25 sets of samples before calculating the heart rate.
  for (byte i = 75; i < 100; i++)
  {
    while (particleSensor.available() == false) //do we have new data?
      particleSensor.check(); //Check the sensor for new data

    redBuffer[i] = particleSensor.getRed();
    irBuffer[i] = particleSensor.getIR();
    particleSensor.nextSample(); //We're finished with this sample so move to next sample

    //send samples and calculation result to terminal program through UART
    Serial.print(F("red="));
    Serial.print(redBuffer[i], DEC);
    Serial.print(F(", ir="));
    Serial.print(irBuffer[i], DEC);

    Serial.print(F(", HR="));
    Serial.print(heartRate, DEC);

    Serial.print(F(", HRvalid="));
    Serial.print(validHeartRate, DEC);

    Serial.print(F(", SPO2="));
    Serial.print(spo2, DEC);

    Serial.print(F(", SPO2Valid="));
    Serial.println(validSPO2, DEC);
    }

    //After gathering 25 new samples recalculate HR and SP02
    maxim_heart_rate_and_oxygen_saturation(irBuffer, bufferLength, redBuffer, &spo2, &validSPO2, &heartRate, &validHeartRate);
}

// put function definitions here
float getBattVoltage(int x) {
  float voltage = (x * 2 * 3.6) / 1024.0; 
  return constrain(voltage, 0.0, 4.2);  // LiPo max voltage is 4.2V

}

void VBatIndicator() {
    if (VBat > 4.1) {
    pixel.setPixelColor(0, pixel.Color(0, 255, 0)); // Green indicate full batt
  }
  else if (VBat < 3.4) {
    pixel.setPixelColor(0, pixel.Color(255, 0, 0)); // Red indicate low batt
  }
  else {
    pixel.setPixelColor(0, pixel.Color(0, 0, 255)); // Blue indicate otherwise
  }
  pixel.show();  // Call show() only once after setting the color
}

void FillSensorBuffer() {
  //read the first 100 samples, and determine the signal range
  Serial.println("Collecting samples...");
  //finger detection
  if (particleSensor.getIR() < 7000) {
      Serial.println("No finger detected");
      return;
  }
  for (byte i = 0 ; i < bufferLength ; i++)
  {
    while (particleSensor.available() == false) //do we have new data?
      particleSensor.check(); //Check the sensor for new data

    redBuffer[i] = particleSensor.getRed();
    irBuffer[i] = particleSensor.getIR();
    particleSensor.nextSample(); //We're finished with this sample so move to next sample

    // Print progress
    if (i % 10 == 0) {  // Print every 10th sample
      Serial.print("Progress: ");
      Serial.print(i);
      Serial.println("%");
    }
  }
  Serial.println("Samples Collected!");
}